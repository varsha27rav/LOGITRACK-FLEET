package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class LogitrackApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(LogitrackApiGatewayApplication.class, args);
    }

}
