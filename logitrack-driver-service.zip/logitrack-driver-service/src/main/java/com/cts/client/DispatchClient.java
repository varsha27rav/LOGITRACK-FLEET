package com.cts.client;

import com.cts.dto.RouteScheduleDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "logitrack-dispatch-service")
public interface DispatchClient {

    @GetMapping("/api/dispatcher/schedules/{scheduleId}")
    RouteScheduleDTO getScheduleById(@PathVariable Long scheduleId);

    @GetMapping("/api/dispatcher/schedules/driver/{driverId}")
    java.util.List<RouteScheduleDTO> getSchedulesByDriverId(@PathVariable Long driverId);

    @PutMapping("/api/dispatcher/schedules/{scheduleId}/status")
    void updateScheduleStatus(@PathVariable Long scheduleId, @RequestBody String status);
}