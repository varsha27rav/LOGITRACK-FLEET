package com.cts.dao;

import com.cts.entity.TripLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TripLogRepository extends JpaRepository<TripLog, Long> {
    List<TripLog> findByDriverId(Long driverId);
    List<TripLog> findByVehicleId(Long vehicleId);
}