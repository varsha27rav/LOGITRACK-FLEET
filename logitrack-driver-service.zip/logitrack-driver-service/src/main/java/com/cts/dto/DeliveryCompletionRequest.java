package com.cts.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class DeliveryCompletionRequest {
    @NotBlank(message = "OTP is required")
    private String otp;

    @NotBlank(message = "Proof of receipt file is required")
    private String fileUri;

    @NotNull(message = "Distance is required")
    private Double distance;

    private String notes; // Optional notes from the driver
}