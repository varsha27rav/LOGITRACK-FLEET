package com.cts.common.constants;

public enum Role {
    USER, ADMIN, CUSTOMER, DISPATCHER, FLEET_MANAGER, DRIVER, AUDITOR
}
