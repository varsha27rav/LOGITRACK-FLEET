package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing
@SpringBootApplication
public class LogitrackShipmentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(LogitrackShipmentServiceApplication.class, args);
    }

}
