package com.cts.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class InspectionRequest {
    @NotNull(message = "Vehicle ID is required")
    private Long vehicleId;

    @NotNull
    @Min(1) @Max(5)
    private Integer conditionRating;

    @NotBlank(message = "Findings cannot be empty")
    private String findings;

    private String photoUri;

    @NotBlank(message = "Status (PASSED/FAILED) is required")
    private String status;
}