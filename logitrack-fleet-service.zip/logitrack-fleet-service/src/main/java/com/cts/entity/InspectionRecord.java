package com.cts.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "inspection_records")
@Data
public class InspectionRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long inspectionId;

    private Long vehicleId;
    private Long inspectorId; // Fleet Manager ID
    private LocalDateTime performedAt;

    private Integer conditionRating; // 1 (Poor) to 5 (Excellent)
    private String findings;
    private String photoUri;

    @Enumerated(EnumType.STRING)
    private InspectionStatus status;

    public enum InspectionStatus {
        PASSED, FAILED
    }
}