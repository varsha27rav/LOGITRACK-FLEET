package com.cts.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.dto.VehicleDTO;

@FeignClient(name = "logitrack-fleet-service")
public interface VehicleClient {

    @GetMapping("/api/fleet/vehicles/{id}")
    VehicleDTO getVehicleById(@PathVariable Long id);
}
