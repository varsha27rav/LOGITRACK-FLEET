package com.cts.dto;

import lombok.Data;

@Data
public class ShipmentDTO {
    private Long shipmentId;
    private Long customerId;
    private String origin;
    private String destination;
    private Double weight;
    private String receiverName;
    private String receiverPhone;
    private String status;
    private String deliveryOtp;
}
