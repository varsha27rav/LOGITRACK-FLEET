package com.cts.service;

import com.cts.client.ShipmentClient;
import com.cts.client.VehicleClient;
import com.cts.common.dao.AuditLogRepository;
import com.cts.common.entity.AuditLog;
import com.cts.dao.DriverAssignmentRepository;
import com.cts.dao.RouteScheduleRepository;
import com.cts.dto.DispatchRequest;
import com.cts.dto.ShipmentDTO;
import com.cts.dto.VehicleDTO;
import com.cts.entity.DriverAssignment;
import com.cts.entity.RouteSchedule;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class DispatcherService {

    private final RouteScheduleRepository routeScheduleRepository;
    private final DriverAssignmentRepository driverAssignmentRepository;
    private final AuditLogRepository auditLogRepository;
    private final ShipmentClient shipmentClient;
    private final VehicleClient vehicleClient;

    public DispatcherService(RouteScheduleRepository routeScheduleRepository,
                             DriverAssignmentRepository driverAssignmentRepository,
                             AuditLogRepository auditLogRepository,
                             ShipmentClient shipmentClient,
                             VehicleClient vehicleClient) {
        this.routeScheduleRepository = routeScheduleRepository;
        this.driverAssignmentRepository = driverAssignmentRepository;
        this.auditLogRepository = auditLogRepository;
        this.shipmentClient = shipmentClient;
        this.vehicleClient = vehicleClient;
    }

    @Transactional
    public void dispatchShipment(DispatchRequest request, Long dispatcherId) {
        // 1. Get Vehicle from fleet-service via Feign
        VehicleDTO vehicle = vehicleClient.getVehicleById(request.getVehicleId());

        if (!vehicle.getStatus().equals("AVAILABLE")) {
            throw new RuntimeException("Vehicle " + vehicle.getRegNumber() +
                    " is currently " + vehicle.getStatus() +
                    " and cannot be assigned.");
        }

        // 2. Check Shipment not already scheduled
        Optional<RouteSchedule> existing = routeScheduleRepository
                .findByShipmentId(request.getShipmentId());
        if (existing.isPresent()) {
            throw new RuntimeException("Shipment #" + request.getShipmentId() +
                    " is already scheduled.");
        }

        // 3. Get Shipment from shipment-service via Feign
        ShipmentDTO shipment = shipmentClient.getShipmentById(request.getShipmentId());

        // 4. Update Shipment status via Feign
        shipmentClient.updateShipmentStatus(request.getShipmentId(), "ACCEPTED");

        // 5. Create Route Schedule
        RouteSchedule schedule = new RouteSchedule();
        schedule.setShipmentId(request.getShipmentId());
        schedule.setVehicleId(request.getVehicleId());
        schedule.setRouteId(request.getRouteId());
        schedule.setDepartureAt(request.getDepartureAt());
        schedule.setArrivalAt(request.getArrivalAt());
        schedule.setDispatcherId(dispatcherId);
        schedule.setStatus(RouteSchedule.ScheduleStatus.SCHEDULED);
        routeScheduleRepository.save(schedule);

        // 6. Create Driver Assignment
        DriverAssignment assignment = new DriverAssignment();
        assignment.setDriverId(request.getDriverId());
        assignment.setVehicleId(request.getVehicleId());
        assignment.setRouteId(request.getRouteId());
        assignment.setAssignedBy(dispatcherId);
        assignment.setAssignedAt(LocalDateTime.now());
        assignment.setStatus("ACTIVE");
        driverAssignmentRepository.save(assignment);

        // 7. Audit
        auditLogRepository.save(new AuditLog(dispatcherId, "DISPATCH_CREATED",
                "Shipment " + shipment.getShipmentId() +
                        " assigned to vehicle " + vehicle.getRegNumber()));
    }

    @Transactional
    public void cancelFullDispatch(Long shipmentId, Long dispatcherId) {
        // 1. Cancel Shipment via Feign
        shipmentClient.updateShipmentStatus(shipmentId, "CANCELLED");

        // 2. Cancel Route Schedule
        routeScheduleRepository.findByShipmentId(shipmentId).ifPresent(s -> {
            s.setStatus(RouteSchedule.ScheduleStatus.CANCELLED);
            routeScheduleRepository.save(s);
        });

        // 3. Cancel Driver Assignments
        driverAssignmentRepository.findAll().stream()
                .filter(a -> a.getStatus().equals("ACTIVE") &&
                        a.getAssignedBy().equals(dispatcherId))
                .forEach(a -> {
                    a.setStatus("CANCELLED");
                    driverAssignmentRepository.save(a);
                });

        // 4. Audit
        auditLogRepository.save(new AuditLog(dispatcherId, "DISPATCH_CANCELLED",
                "Full cancellation of Shipment #" + shipmentId));
    }
}


