package com.cts.config;

public class DatabaseConfig {

}
