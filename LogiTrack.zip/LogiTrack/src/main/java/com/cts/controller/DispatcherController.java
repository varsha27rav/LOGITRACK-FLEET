package com.cts.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dao.AuditLogRepository;
import com.cts.dao.ShipmentRepository;
import com.cts.dao.UserRepository;
import com.cts.dto.DispatchRequest;
import com.cts.entity.AuditLog;
import com.cts.entity.Shipment;
import com.cts.entity.User;
import com.cts.service.DispatcherService;

@RestController
@RequestMapping("/api/dispatcher")
@PreAuthorize("hasAnyRole('ADMIN', 'DISPATCHER')")
public class DispatcherController {

	private final DispatcherService dispatcherService;
    private final ShipmentRepository shipmentRepository;
    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;

    public DispatcherController(DispatcherService dispatcherService, 
                                ShipmentRepository shipmentRepository,
                                AuditLogRepository auditLogRepository,
                                UserRepository userRepository) {
        this.dispatcherService = dispatcherService;
        this.shipmentRepository = shipmentRepository;
        this.auditLogRepository = auditLogRepository;
        this.userRepository = userRepository;
    }

    // 1. Get All Shipments (with optional filtering)
    // URL Example: /api/dispatcher/shipments?customerId=5&status=PENDING
    @GetMapping("/shipments")
    public ResponseEntity<List<Shipment>> getShipments(
            @RequestParam(required = false) Long customerId,
            @RequestParam(required = false) Shipment.ShipmentStatus status) {
        
        if (customerId != null && status != null) {
            return ResponseEntity.ok(shipmentRepository.findByCustomerIdAndStatus(customerId, status));
        } else if (customerId != null) {
            return ResponseEntity.ok(shipmentRepository.findByCustomerId(customerId));
        } else if (status != null) {
            return ResponseEntity.ok(shipmentRepository.findByStatus(status));
        }
        
        return ResponseEntity.ok(shipmentRepository.findAll());
    }

    // 2. Cancel a Shipment
    @PutMapping("/shipments/{id}/cancel")
    public ResponseEntity<?> cancelShipment(@PathVariable Long id, Authentication auth) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));
        
        shipment.setStatus(Shipment.ShipmentStatus.CANCELLED);
        shipmentRepository.save(shipment);

        // Audit the cancellation
        User dispatcher = userRepository.findByEmail(auth.getName()).orElseThrow();
        auditLogRepository.save(new AuditLog(dispatcher.getUserId(), "SHIPMENT_CANCELLED", 
            "Dispatcher cancelled shipment ID: " + id));

        return ResponseEntity.ok(Map.of("message", "Shipment cancelled successfully."));
    }

    @PostMapping("/dispatch")
    public ResponseEntity<?> processDispatch(Authentication auth, @RequestBody DispatchRequest request) {
        User dispatcher = userRepository.findByEmail(auth.getName()).orElseThrow();
        dispatcherService.dispatchShipment(request, dispatcher.getUserId());
        return ResponseEntity.ok(Map.of("message", "Shipment dispatched and driver assigned successfully."));
    }
    
    @PutMapping("/shipments/{id}/cancel-dispatch")
    public ResponseEntity<?> cancelDispatch(@PathVariable Long id, Authentication auth) {
        User dispatcher = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Dispatcher not found"));

        dispatcherService.cancelFullDispatch(id, dispatcher.getUserId());
        
        return ResponseEntity.ok(Map.of("message", "Shipment, Schedule, and Driver Assignment cancelled successfully."));
    }
}