package com.cts.controller;

import com.cts.entity.Shipment;
import com.cts.entity.User;
import com.cts.dto.ShipmentRequest;
import com.cts.service.ShipmentService;
import com.cts.dao.ShipmentRepository;
import com.cts.dao.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shipments")
public class ShipmentController {

    private final ShipmentService shipmentService;
    private final UserRepository userRepository;
    private final ShipmentRepository shipmentRepository;

    public ShipmentController(ShipmentService shipmentService, UserRepository userRepository, ShipmentRepository shipmentRepository) {
        this.shipmentService = shipmentService;
        this.userRepository = userRepository;
        this.shipmentRepository = shipmentRepository;
    }

    @PostMapping("/create")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<Shipment> placeOrder(Authentication authentication, 
                                             @RequestBody ShipmentRequest request) {
        // Get the email from the JWT token via Authentication object
        String email = authentication.getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return ResponseEntity.ok(shipmentService.createShipment(user.getUserId(), request));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<Shipment> trackShipment(@PathVariable Long id) {
        return ResponseEntity.ok(shipmentService.getShipmentStatus(id));
    }

    @GetMapping("/my-orders")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<List<Shipment>> getMyOrders(Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return ResponseEntity.ok(shipmentService.getCustomerShipments(user.getUserId()));
    }
    
    @PostMapping("/{id}/verify-delivery")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<?> verifyDelivery(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String inputOtp = body.get("otp");
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));

        if (shipment.getDeliveryOtp().equals(inputOtp)) {
            shipment.setStatus(Shipment.ShipmentStatus.DELIVERED);
            shipmentRepository.save(shipment);
            
            return ResponseEntity.ok(Map.of("message", "Delivery successful! Status updated to DELIVERED."));
        } else {
            return ResponseEntity.status(400).body(Map.of("message", "Invalid OTP. Delivery could not be verified."));
        }
    }
}