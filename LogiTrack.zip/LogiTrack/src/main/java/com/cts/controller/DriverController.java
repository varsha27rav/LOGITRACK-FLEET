package com.cts.controller;

import com.cts.entity.DeliveryRecord;
import com.cts.entity.User;
import com.cts.dao.UserRepository;
import com.cts.dao.DeliveryRecordRepository;
import com.cts.dto.DeliveryCompletionRequest;
import com.cts.dto.DriverRideResponse;
import com.cts.service.DriverService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/driver")
public class DriverController {

    private final DriverService driverService;
    private final UserRepository userRepository;
    private final DeliveryRecordRepository deliveryRecordRepository;

    public DriverController(DriverService driverService, UserRepository userRepository,
                            DeliveryRecordRepository deliveryRecordRepository) {
        this.driverService = driverService;
        this.userRepository = userRepository;
        this.deliveryRecordRepository = deliveryRecordRepository;
    }

    /**
     * Driver submits the OTP and finalizes delivery.
     */
    @PostMapping("/shipments/{id}/complete")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<?> completeDelivery(
            @PathVariable Long id, 
            @Valid @RequestBody DeliveryCompletionRequest request, 
            Authentication auth) {
        
        User driver = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Driver not found"));

        String result = driverService.verifyAndCompleteDelivery(id, request, driver.getUserId());
        
        return ResponseEntity.ok(Map.of("message", result));
    }

    /**
     * Fetch delivery records - Accessible by Admin, Dispatcher, and the Driver.
     */
    @GetMapping("/records/{orderId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DISPATCHER', 'DRIVER')")
    public ResponseEntity<List<DeliveryRecord>> getDeliveryRecords(@PathVariable Long orderId) {
        return ResponseEntity.ok(deliveryRecordRepository.findByOrderId(orderId));
    }
    
    /**
     * Updated: Returns DriverRideResponse DTO which includes addresses and receiver info.
     */
    @GetMapping("/my-rides")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<List<DriverRideResponse>> getMyScheduledRides(Authentication auth) {
        // 1. Get the current logged-in driver details
        User driver = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Driver profile not found"));

        // 2. Fetch the rides via the service (which now handles the mapping to DTO)
        List<DriverRideResponse> rides = driverService.getDriverSchedules(driver.getUserId());
        
        return ResponseEntity.ok(rides);
    }
    
    /**
     * PATCH /api/driver/trips/{scheduleId}/start
     * Driver signals that they are beginning the delivery.
     */
    @PatchMapping("/trips/{scheduleId}/start")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<?> startTrip(@PathVariable Long scheduleId, Authentication auth) {
        User driver = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("Driver not found"));

        String message = driverService.startTrip(scheduleId, driver.getUserId());
        
        return ResponseEntity.ok(Map.of("message", message));
    }
}