package com.cts.common.service;

import org.springframework.stereotype.Service;

@Service
public class EmailService {

    // Commented out to prevent network hang
    // private final JavaMailSender mailSender; 

    public void sendOtpEmail(String to, String otp) {
        System.out.println("************************************************");
        System.out.println("  LOGITRACK MOCK EMAIL SERVICE                ");
        System.out.println("  To: " + to                                   );
        System.out.println("  OTP: " + otp                                 );
        System.out.println("  Expires in: 5 Minutes                       ");
        System.out.println("************************************************");
    }
}