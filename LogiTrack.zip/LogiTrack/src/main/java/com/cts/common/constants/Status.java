package com.cts.common.constants;

public enum Status {
    PENDING, ACTIVE, INACTIVE
}