package com.cts.initializer;

import com.cts.common.constants.Role;
import com.cts.common.constants.Status;
import com.cts.dao.UserRepository;
import com.cts.entity.User;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        String adminEmail = "admin@logitrack.com";

        
        if (userRepository.findByEmail(adminEmail).isEmpty()) {
            User admin = new User();
            
         
            admin.setName("System Admin");
            admin.setEmail(adminEmail);
            admin.setPassword(passwordEncoder.encode("Admin@123")); // Default password
            admin.setRole(Role.ADMIN);
            admin.setStatus(Status.ACTIVE);
            //admin.setCreatedAt(LocalDateTime.now());
            //admin.setUpdatedAt(LocalDateTime.now());

            userRepository.save(admin);
            
            System.out.println("----------------------------------------------");
            System.out.println("LogiTrack: Default Admin Profile Created!");
            System.out.println("Email: admin@logitrack.com");
            System.out.println("Password: Admin@123");
            System.out.println("----------------------------------------------");
        } else {
            System.out.println("LogiTrack: Admin profile already exists. Skipping initialization.");
        }
    }
}