package com.cts.dto;

import lombok.Data;

@Data
public class ShipmentRequest {
    private String origin;
    private String destination;
    private Double weight;
    private String receiverName;
    private String receiverPhone;
}