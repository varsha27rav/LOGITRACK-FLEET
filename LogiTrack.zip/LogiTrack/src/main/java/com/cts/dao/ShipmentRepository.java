package com.cts.dao;

import com.cts.entity.Shipment;
import com.cts.entity.Shipment.ShipmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ShipmentRepository extends JpaRepository<Shipment, Long> {
    List<Shipment> findByCustomerId(Long customerId);
    List<Shipment> findByCustomerIdAndStatus(Long customerId, ShipmentStatus status);
    List<Shipment> findByStatus(ShipmentStatus status);
}