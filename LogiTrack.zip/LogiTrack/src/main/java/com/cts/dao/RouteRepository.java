package com.cts.dao;

import com.cts.entity.Route;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RouteRepository extends JpaRepository<Route, Long> {
    List<Route> findByStatus(Route.RouteStatus status);
}