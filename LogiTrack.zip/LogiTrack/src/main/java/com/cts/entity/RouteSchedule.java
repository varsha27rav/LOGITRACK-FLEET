package com.cts.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "route_schedules")
@Data
public class RouteSchedule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long scheduleId;
    
    private Long vehicleId;
    private Long routeId;
    private LocalDateTime departureAt;
    private LocalDateTime arrivalAt;
    private Long dispatcherId; // The Admin/Dispatcher User ID
    
    @Enumerated(EnumType.STRING)
    private ScheduleStatus status; // SCHEDULED, COMPLETED, CANCELLED
 // Inside com.cts.entity.RouteSchedule
    
    @Column(unique = true)
    private Long shipmentId;

    public Long getShipmentId() { return shipmentId; }
    public void setShipmentId(Long shipmentId) { this.shipmentId = shipmentId; }

    public enum ScheduleStatus {
        SCHEDULED, 
        IN_TRANSIT, 
        COMPLETED,
        CANCELLED
    }
}