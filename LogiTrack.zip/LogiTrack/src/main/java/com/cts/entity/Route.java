package com.cts.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "routes")
@Data
public class Route {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long routeId;

    private String name;

    @Column(columnDefinition = "TEXT") 
    private String stopsJson; // Example: '["Warehouse A", "Hub B", "Client C"]'

    private Double distanceKm;

    @Enumerated(EnumType.STRING)
    private RouteStatus status; // ACTIVE, INACTIVE

    public enum RouteStatus {
        ACTIVE, INACTIVE
    }
}