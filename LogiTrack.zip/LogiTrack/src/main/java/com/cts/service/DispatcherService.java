package com.cts.service;

import com.cts.dao.ShipmentRepository;
import com.cts.dao.RouteScheduleRepository;
import com.cts.dao.DriverAssignmentRepository;
import com.cts.dao.AuditLogRepository;
import com.cts.dao.VehicleRepository; // Added
import com.cts.dto.DispatchRequest;
import com.cts.entity.Shipment;
import com.cts.entity.RouteSchedule;
import com.cts.entity.DriverAssignment;
import com.cts.entity.AuditLog;
import com.cts.entity.Vehicle; // Added
import jakarta.persistence.EntityNotFoundException; // For 404 response

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class DispatcherService {

    private final ShipmentRepository shipmentRepository;
    private final RouteScheduleRepository routeScheduleRepository;
    private final DriverAssignmentRepository driverAssignmentRepository;
    private final AuditLogRepository auditLogRepository;
    private final VehicleRepository vehicleRepository; // Added

    public DispatcherService(ShipmentRepository shipmentRepository, 
                            RouteScheduleRepository routeScheduleRepository, 
                            DriverAssignmentRepository driverAssignmentRepository, 
                            AuditLogRepository auditLogRepository,
                            VehicleRepository vehicleRepository) {
        this.shipmentRepository = shipmentRepository;
        this.routeScheduleRepository = routeScheduleRepository;
        this.driverAssignmentRepository = driverAssignmentRepository;
        this.auditLogRepository = auditLogRepository;
        this.vehicleRepository = vehicleRepository;
    }
    
    @Transactional
    public void dispatchShipment(DispatchRequest request, Long dispatcherId) {
        // 1. Validation: Vehicle Existence & Status
        Vehicle vehicle = vehicleRepository.findById(request.getVehicleId())
                .orElseThrow(() -> new EntityNotFoundException("Vehicle not found with ID: " + request.getVehicleId()));

        if (vehicle.getStatus() != Vehicle.VehicleStatus.AVAILABLE) {
            throw new RuntimeException("Vehicle " + vehicle.getRegNumber() + " is currently " + 
                vehicle.getStatus() + " and cannot be assigned to a new route.");
        }

        // 2. Validation: Ensure Shipment is not already scheduled (1:1 rule)
        Optional<RouteSchedule> existing = routeScheduleRepository.findByShipmentId(request.getShipmentId());
        if (existing.isPresent()) {
            throw new RuntimeException("Shipment #" + request.getShipmentId() + 
                " is already scheduled. Use modifyDispatch to update details.");
        }

        // 3. Fetch Shipment
        Shipment shipment = shipmentRepository.findById(request.getShipmentId())
                .orElseThrow(() -> new EntityNotFoundException("Shipment not found with ID: " + request.getShipmentId()));

        // 4. Generate Delivery OTP and update Shipment
        String deliveryOtp = String.valueOf((int)((Math.random() * 900000) + 100000));
        shipment.setDeliveryOtp(deliveryOtp);
        shipment.setStatus(Shipment.ShipmentStatus.ACCEPTED); 
        shipmentRepository.save(shipment);

        // 5. Create Route Schedule
        RouteSchedule schedule = new RouteSchedule();
        schedule.setShipmentId(request.getShipmentId());
        schedule.setVehicleId(request.getVehicleId());
        schedule.setRouteId(request.getRouteId());
        schedule.setDepartureAt(request.getDepartureAt());
        schedule.setArrivalAt(request.getArrivalAt());
        schedule.setDispatcherId(dispatcherId);
        schedule.setStatus(RouteSchedule.ScheduleStatus.SCHEDULED);
        routeScheduleRepository.save(schedule);

        // 6. Create Driver Assignment
        DriverAssignment assignment = new DriverAssignment();
        assignment.setDriverId(request.getDriverId());
        assignment.setVehicleId(request.getVehicleId());
        assignment.setRouteId(request.getRouteId());
        assignment.setAssignedBy(dispatcherId);
        assignment.setAssignedAt(LocalDateTime.now());
        assignment.setStatus("ACTIVE");
        driverAssignmentRepository.save(assignment);

        // 7. Audit
        auditLogRepository.save(new AuditLog(dispatcherId, "DISPATCH_CREATED", 
            "Shipment " + shipment.getShipmentId() + " assigned to vehicle " + vehicle.getRegNumber()));
    }

    /**
     * Feature: Modify an existing schedule. 
     * Includes check to ensure vehicle isn't changed to one in maintenance.
     */
    @Transactional
    public void modifyDispatch(Long shipmentId, DispatchRequest request, Long dispatcherId) {
        RouteSchedule schedule = routeScheduleRepository.findByShipmentId(shipmentId)
                .orElseThrow(() -> new EntityNotFoundException("No existing schedule found for Shipment #" + shipmentId));

        if (schedule.getStatus() != RouteSchedule.ScheduleStatus.SCHEDULED) {
            throw new RuntimeException("Cannot modify a schedule that is already " + schedule.getStatus());
        }

        // Validate new vehicle status if vehicle is being changed
        Vehicle vehicle = vehicleRepository.findById(request.getVehicleId())
                .orElseThrow(() -> new EntityNotFoundException("Vehicle not found with ID: " + request.getVehicleId()));
        
        if (vehicle.getStatus() != Vehicle.VehicleStatus.AVAILABLE) {
            throw new RuntimeException("New vehicle " + vehicle.getRegNumber() + " is in maintenance.");
        }

        // Update logistics
        schedule.setVehicleId(request.getVehicleId());
        schedule.setRouteId(request.getRouteId());
        schedule.setDepartureAt(request.getDepartureAt());
        schedule.setArrivalAt(request.getArrivalAt());
        routeScheduleRepository.save(schedule);

        // Audit Log
        auditLogRepository.save(new AuditLog(dispatcherId, "DISPATCH_MODIFIED", 
            "Updated vehicle/route for Shipment #" + shipmentId));
    }

    @Transactional
    public void cancelFullDispatch(Long shipmentId, Long dispatcherId) {
        // 1. Cancel the Shipment
        Shipment shipment = shipmentRepository.findById(shipmentId)
                .orElseThrow(() -> new EntityNotFoundException("Shipment not found"));
        shipment.setStatus(Shipment.ShipmentStatus.CANCELLED);
        shipmentRepository.save(shipment);

        // 2. Cancel the specific Route Schedule
        routeScheduleRepository.findByShipmentId(shipmentId).ifPresent(s -> {
            s.setStatus(RouteSchedule.ScheduleStatus.CANCELLED);
            routeScheduleRepository.save(s);
        });

        // 3. Deactivate associated Driver Assignments
        driverAssignmentRepository.findAll().stream()
            .filter(a -> a.getStatus().equals("ACTIVE") && a.getAssignedBy().equals(dispatcherId))
            .forEach(a -> {
                a.setStatus("CANCELLED");
                driverAssignmentRepository.save(a);
            });

        // 4. Audit Log
        auditLogRepository.save(new AuditLog(dispatcherId, "DISPATCH_CANCELLED", 
            "Full cancellation of Shipment #" + shipmentId));
    }
}