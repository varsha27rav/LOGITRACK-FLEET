package com.cts.service;

import com.cts.dao.ShipmentRepository;
import com.cts.dao.AuditLogRepository;
import com.cts.entity.Shipment;
import com.cts.entity.AuditLog;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class ShipmentService {

    private final ShipmentRepository shipmentRepository;
    private final AuditLogRepository auditLogRepository;

    public ShipmentService(ShipmentRepository shipmentRepository, AuditLogRepository auditLogRepository) {
        this.shipmentRepository = shipmentRepository;
        this.auditLogRepository = auditLogRepository;
    }

    @Transactional
    public Shipment createShipment(Long customerId, com.cts.dto.ShipmentRequest request) {
        Shipment shipment = new Shipment();
        shipment.setCustomerId(customerId);
        shipment.setOrigin(request.getOrigin());
        shipment.setDestination(request.getDestination());
        shipment.setWeight(request.getWeight());
        shipment.setReceiverName(request.getReceiverName());
        shipment.setReceiverPhone(request.getReceiverPhone());
        shipment.setStatus(Shipment.ShipmentStatus.PENDING);

        Shipment saved = shipmentRepository.save(shipment);

        // Audit the order placement
        auditLogRepository.save(new AuditLog(customerId, "SHIPMENT_CREATED", 
            "Order #" + saved.getShipmentId() + " placed from " + saved.getOrigin()));

        return saved;
    }

    public Shipment getShipmentStatus(Long shipmentId) {
        return shipmentRepository.findById(shipmentId)
            .orElseThrow(() -> new RuntimeException("Shipment not found"));
    }

    public List<Shipment> getCustomerShipments(Long customerId) {
        return shipmentRepository.findByCustomerId(customerId);
    }
}