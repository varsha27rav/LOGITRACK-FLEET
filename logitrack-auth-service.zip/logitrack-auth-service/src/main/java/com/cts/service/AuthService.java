package com.cts.service;

import com.cts.common.constants.Role;
import com.cts.common.constants.Status;
import com.cts.common.dao.UserRepository;
import com.cts.common.dao.AuditLogRepository;
import com.cts.dao.DriverRepository;
import com.cts.dto.RegisterRequest;
import com.cts.common.entity.User;
import com.cts.common.security.JwtTokenProvider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final DriverRepository driverRepository;
    private final AuditLogRepository auditLogRepository;
    private final PasswordEncoder passwordEncoder;
    private final OtpService otpService;
    private final JwtTokenProvider tokenProvider;

    public AuthService(UserRepository userRepository,
                       DriverRepository driverRepository,
                       AuditLogRepository auditLogRepository,
                       PasswordEncoder passwordEncoder,
                       OtpService otpService,
                       JwtTokenProvider tokenProvider) {
        this.userRepository = userRepository;
        this.driverRepository = driverRepository;
        this.auditLogRepository = auditLogRepository;
        this.passwordEncoder = passwordEncoder;
        this.otpService = otpService;
        this.tokenProvider = tokenProvider;
    }

    @Transactional
    public String registerUser(RegisterRequest data) {
        String email = data.getEmail();
        String otp = data.getOtpCode();

        if (!otpService.validateOtp(email, otp)) {
            throw new RuntimeException("Invalid or Expired OTP.");
        }

        Optional<User> existingUser = userRepository.findByEmail(email);
        if (existingUser.isPresent()) {
            User user = existingUser.get();
            if (user.getStatus() == Status.INACTIVE) {
                throw new RuntimeException("This account is deactivated. Please contact support for reactivation.");
            } else {
                throw new RuntimeException("Email already exists. Please login instead.");
            }
        }

        if (userRepository.findByPhoneNumber(data.getPhoneNumber()).isPresent()) {
            throw new RuntimeException("Phone number is already associated with another account.");
        }

        User user = new User();
        user.setName(data.getName());
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(data.getPassword()));
        user.setPhoneNumber(data.getPhoneNumber());
        user.setRole(Role.CUSTOMER);
        user.setStatus(Status.ACTIVE);

        User savedUser = userRepository.save(user);

        // Log Registration
        auditLogRepository.save(new AuditLog(savedUser.getUserId(), "REGISTRATION", "User registered and verified via OTP"));

        return "Registration Successful!";
    }

    public String login(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getStatus() == Status.INACTIVE) {
            throw new RuntimeException("Account is inactive. Access denied.");
        }

        if (!passwordEncoder.matches(password, user.getPassword())) {
            auditLogRepository.save(new AuditLog(user.getUserId(), "LOGIN_FAILURE", "Invalid password attempt for email: " + email));
            throw new RuntimeException("Invalid credentials");
        }

        auditLogRepository.save(new AuditLog(user.getUserId(), "LOGIN_SUCCESS", "User logged in successfully"));
        return tokenProvider.generateToken(user.getEmail(), user.getRole().name());
    }

    @Transactional
    public String resetPassword(String email, String otp, String newPassword) {
        if (!otpService.validateOtp(email, otp)) {
            throw new RuntimeException("Invalid OTP for password reset.");
        }
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        auditLogRepository.save(new AuditLog(user.getUserId(), "PASSWORD_RESET", "User successfully reset their password via OTP"));

        return "Password reset successful";
    }

    public String recoverUsername(String phoneNumber, String otp) {
        if (!otpService.validateOtp(phoneNumber, otp)) {
            throw new RuntimeException("Invalid OTP for recovery.");
        }
        User user = userRepository.findByPhoneNumber(phoneNumber)
                .orElseThrow(() -> new RuntimeException("Phone number not found"));

        auditLogRepository.save(new AuditLog(user.getUserId(), "USERNAME_RECOVERY", "User recovered email via phone OTP"));

        return user.getEmail();
    }
}