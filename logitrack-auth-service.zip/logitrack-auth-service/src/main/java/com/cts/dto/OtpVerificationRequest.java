package com.cts.dto;

import lombok.Data;

@Data
public class OtpVerificationRequest {
    private String email;
    private String code;
}