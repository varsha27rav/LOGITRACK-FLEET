package com.cts.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request body for user registration")
public class RegisterRequest {

    @Schema(example = "John Doe", description = "Full name of the user", requiredMode = Schema.RequiredMode.REQUIRED)
    private String name;

    @Schema(example = "john.doe@example.com", description = "Unique email address for the account", requiredMode = Schema.RequiredMode.REQUIRED)
    private String email;

    @Schema(example = "P@ssword123", description = "Secure password for the account", requiredMode = Schema.RequiredMode.REQUIRED)
    private String password;

    @Schema(example = "9876543210", description = "Primary phone number of the user", requiredMode = Schema.RequiredMode.REQUIRED)
    private String phoneNumber;

    @Schema(example = "123456", description = "The OTP code sent to the user's email/phone", requiredMode = Schema.RequiredMode.REQUIRED)
    private String otpCode;
}