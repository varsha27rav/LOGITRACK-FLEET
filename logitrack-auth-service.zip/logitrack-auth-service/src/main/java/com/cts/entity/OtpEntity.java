package com.cts.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "otps")
public class OtpEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String email;
    private String code;
    private LocalDateTime expiryDate;

    public OtpEntity() {}
    public OtpEntity(String email, String code, int minutes) {
        this.email = email;
        this.code = code;
        this.expiryDate = LocalDateTime.now().plusMinutes(minutes);
    }

    public String getCode() { return code; }
    public LocalDateTime getExpiryDate() { return expiryDate; }
    public String getEmail() { return email; }
    // Add remaining setters manually...
}