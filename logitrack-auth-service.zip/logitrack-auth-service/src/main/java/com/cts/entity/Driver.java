package com.cts.entity;

import com.cts.common.entity.User;
import jakarta.persistence.*;

@Entity
@Table(name = "drivers")
public class Driver {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    private String licenseNumber;
    private String status; // AVAILABLE, ON_TRIP
    private String contactInfo;

    public Driver() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public String getLicenseNumber() { return licenseNumber; }
    public void setLicenseNumber(String licenseNumber) { this.licenseNumber = licenseNumber; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public void setContactInfo(String contactInfo) {
        this.contactInfo=contactInfo;

    }

    public String getContactInfo() {
        return contactInfo;
    }
}