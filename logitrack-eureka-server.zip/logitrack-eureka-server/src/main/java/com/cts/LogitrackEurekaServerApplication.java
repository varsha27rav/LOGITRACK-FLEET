package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class LogitrackEurekaServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(LogitrackEurekaServerApplication.class, args);
    }

}
