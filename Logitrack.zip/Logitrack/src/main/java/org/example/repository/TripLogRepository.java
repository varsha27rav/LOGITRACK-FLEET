package org.example.repository;

import org.example.entity.TripLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TripLogRepository extends JpaRepository<TripLog, Long> {

    List<TripLog> findByDriver_Id(Long driverId);

    List<TripLog> findByVehicle_Id(Long vehicleId);

    List<TripLog> findByStatus(String status);

    List<TripLog> findByDriver_IdAndStatus(Long driverId, String status);
}