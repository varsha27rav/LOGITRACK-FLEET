package org.example.repository;

import org.example.entity.DriverAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DriverAssignmentRepository extends JpaRepository<DriverAssignment, Long> {

    List<DriverAssignment> findByDriver_Id(Long driverId);

    List<DriverAssignment> findByVehicle_Id(Long vehicleId);

    List<DriverAssignment> findByStatus(String status);
}