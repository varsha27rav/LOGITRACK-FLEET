package org.example.repository;

import org.example.entity.RouteSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RouteScheduleRepository extends JpaRepository<RouteSchedule,Long>{
    List<RouteSchedule> findByVehicle_Id(Long vehicleId);
    List<RouteSchedule> findByStatus(String status);
    List<RouteSchedule> findByVehicle_IdAndStatus(Long vehicleID,String status);
}
