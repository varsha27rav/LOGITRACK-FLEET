package org.example.mapper;

import org.example.dto.DriverDTO;
import org.example.entity.Driver;

public class DriverMapper {

    public static DriverDTO toDTO(Driver driver) {
        return DriverDTO.builder()
                .id(driver.getId())
                .name(driver.getName())
                .licenseNumber(driver.getLicenseNumber())
                .status(driver.getStatus())
                .build();
    }

    public static Driver toEntity(DriverDTO dto) {
        return Driver.builder()
                .id(dto.getId())
                .name(dto.getName())
                .licenseNumber(dto.getLicenseNumber())
                .status(dto.getStatus())
                .build();
    }
}
