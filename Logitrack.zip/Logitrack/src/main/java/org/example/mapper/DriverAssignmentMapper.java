package org.example.mapper;
import org.example.dto.DriverAssignmentDTO;
import org.example.entity.DriverAssignment;
import org.example.entity.Driver;
import org.example.entity.Vehicle;
import org.example.entity.RouteSchedule;

public class DriverAssignmentMapper {

    public static DriverAssignmentDTO toDTO(DriverAssignment entity) {
        return DriverAssignmentDTO.builder()
                .id(entity.getId())
                .driverId(entity.getDriver().getId())
                .vehicleId(entity.getVehicle().getId())
                .scheduleId(entity.getSchedule().getId())
                .status(entity.getStatus())
                .build();
    }

    public static DriverAssignment toEntity(DriverAssignmentDTO dto) {
        return DriverAssignment.builder()
                .id(dto.getId())
                .driver(Driver.builder().id(dto.getDriverId()).build())
                .vehicle(Vehicle.builder().id(dto.getVehicleId()).build())
                .schedule(RouteSchedule.builder().id(dto.getScheduleId()).build())
                .status(dto.getStatus())
                .build();
    }
}
