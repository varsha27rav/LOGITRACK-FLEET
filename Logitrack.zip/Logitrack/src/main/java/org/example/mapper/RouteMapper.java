package org.example.mapper;

import org.example.dto.RouteDTO;
import org.example.entity.Route;

public class RouteMapper {

    public static RouteDTO toDTO(Route route) {
        return RouteDTO.builder()
                .id(route.getId())
                .name(route.getName())
                .stopsJSON(route.getStopsJSON())
                .distanceKm(route.getDistanceKm())
                .status(route.getStatus())
                .build();
    }
    public static Route toEntity(RouteDTO dto) {
        return Route.builder()
                .id(dto.getId())
                .name(dto.getName())
                .stopsJSON(dto.getStopsJSON())
                .distanceKm(dto.getDistanceKm())
                .status(dto.getStatus())
                .build();
    }
}