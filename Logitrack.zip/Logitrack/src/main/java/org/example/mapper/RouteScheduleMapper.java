
package org.example.mapper;

import org.example.dto.RouteScheduleDTO;
import org.example.entity.RouteSchedule;
import org.example.entity.Vehicle;
import org.example.entity.Route;

public class RouteScheduleMapper {

    public static RouteScheduleDTO toDTO(RouteSchedule entity) {
        return RouteScheduleDTO.builder()
                .id(entity.getId())
                .vehicleId(entity.getVehicle().getId())
                .routeId(entity.getRoute().getId())
                .departureAt(entity.getDepartureAt())
                .arrivalAt(entity.getArrivalAt())
                .dispatcherId(entity.getDispatcherId())
                .status(entity.getStatus())
                .build();
    }

    public static RouteSchedule toEntity(RouteScheduleDTO dto) {
        return RouteSchedule.builder()
                .id(dto.getId())
                .vehicle(Vehicle.builder().id(dto.getVehicleId()).build())
                .route(Route.builder().id(dto.getRouteId()).build())
                .departureAt(dto.getDepartureAt())
                .arrivalAt(dto.getArrivalAt())
                .dispatcherId(dto.getDispatcherId())
                .status(dto.getStatus())
                .build();
    }
}
