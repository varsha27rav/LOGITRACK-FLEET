package org.example.mapper;

import org.example.dto.VehicleDTO;
import org.example.entity.Vehicle;

public class VehicleMapper {

    public static VehicleDTO toDTO(Vehicle vehicle) {
        return VehicleDTO.builder()
                .id(vehicle.getId())
                .regNumber(vehicle.getRegNumber())
                .type(vehicle.getType())
                .capacity(vehicle.getCapacity())
                .status(vehicle.getStatus())
                .build();
    }

    public static Vehicle toEntity(VehicleDTO dto) {
        return Vehicle.builder()
                .id(dto.getId())
                .regNumber(dto.getRegNumber())
                .type(dto.getType())
                .capacity(dto.getCapacity())
                .status(dto.getStatus())
                .build();
    }
}



