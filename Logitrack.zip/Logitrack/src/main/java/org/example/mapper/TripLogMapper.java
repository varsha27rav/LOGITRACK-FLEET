package org.example.mapper;

import org.example.dto.TripLogDTO;
import org.example.entity.TripLog;
import org.example.entity.Driver;
import org.example.entity.Vehicle;
import org.example.entity.Route;

public class TripLogMapper {

    public static TripLogDTO toDTO(TripLog entity) {
        return TripLogDTO.builder()
                .Id(entity.getId())
                .vehicleId(entity.getVehicle().getId())
                .driverId(entity.getDriver().getId())
                .routeId(entity.getRoute().getId())
                .startAt(entity.getStartAt())
                .endAt(entity.getEndAt())
                .distanceKm(entity.getDistanceKm())
                .notes(entity.getNotes())
                .status(entity.getStatus())
                .build();
    }

    public static TripLog toEntity(TripLogDTO dto) {
        return TripLog.builder()
                .id(dto.getId())
                .vehicle(Vehicle.builder().id(dto.getVehicleId()).build())
                .driver(Driver.builder().id(dto.getDriverId()).build())
                .route(Route.builder().id(dto.getRouteId()).build())
                .startAt(dto.getStartAt())
                .endAt(dto.getEndAt())
                .distanceKm(dto.getDistanceKm())
                .notes(dto.getNotes())
                .status(dto.getStatus())
                .build();
    }
}


