package org.example.service;
import org.example.entity.Driver;
import org.example.repository.DriverRepository;
import org.example.entity.Vehicle;
import org.example.repository.VehicleRepository;
import org.example.entity.DriverAssignment;
import org.example.repository.DriverAssignmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class DriverAssignmentService {

    @Autowired
    private DriverRepository driverRepository;


    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private DriverAssignmentRepository repository;
    public DriverAssignment saveAssignment(DriverAssignment assignment) {

        Long driverId = assignment.getDriver().getId();
        Long vehicleId = assignment.getVehicle().getId();

        // Check driver
        List<DriverAssignment> driverAssignments =
                repository.findByDriver_Id(driverId);

        for (DriverAssignment a : driverAssignments) {
            if (a.getStatus().equals("ASSIGNED")) {
                throw new RuntimeException("Driver already assigned");
            }
        }

        // Check vehicle
        List<DriverAssignment> vehicleAssignments =
                repository.findByVehicle_Id(vehicleId);

        for (DriverAssignment a : vehicleAssignments) {
            if (a.getStatus().equals("ASSIGNED")) {
                throw new RuntimeException("Vehicle already assigned");
            }
        }

        Driver driver=driverRepository.findById(driverId).get();
        driver.setStatus("BUSY");
        driverRepository.save(driver);


        Vehicle vehicle = vehicleRepository.findById(vehicleId).get();
        vehicle.setStatus("BUSY");
        vehicleRepository.save(vehicle);

        return repository.save(assignment);
    }
    public List<DriverAssignment> getAllAssignments() {
        return repository.findAll();
    }
    public List<DriverAssignment> getByDriver(Long driverId) {
        return repository.findByDriver_Id(driverId);
    }
    public List<DriverAssignment> getByVehicle(Long vehicleId) {
        return repository.findByVehicle_Id(vehicleId);
    }
    public List<DriverAssignment> getByStatus(String status) {
        return repository.findByStatus(status);
    }
}