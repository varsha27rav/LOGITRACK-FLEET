package org.example.service;
import org.example.entity.RouteSchedule;
import org.example.repository.RouteScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class RouteScheduleService {
    @Autowired
    private RouteScheduleRepository repository;
    public RouteSchedule saveSchedule(RouteSchedule schedule) {
        return repository.save(schedule);
    }
    public List<RouteSchedule> getAllSchedules() {
        return repository.findAll();
    }
    public List<RouteSchedule> getByVehicle(Long vehicleId) {
        return repository.findByVehicle_Id(vehicleId);
    }
    public List<RouteSchedule> getByStatus(String status) {
        return repository.findByStatus(status);
    }
    public RouteSchedule getById(Long id) {
        return repository.findById(id).orElse(null);
    }
}