package org.example.service;
import org.example.entity.TripLog;
import org.example.repository.TripLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import org.example.entity.DriverAssignment;
import org.example.repository.DriverAssignmentRepository;

import org.example.entity.Driver;
import org.example.entity.Vehicle;
import org.example.repository.DriverRepository;
import org.example.repository.VehicleRepository;

@Service
public class TripLogService {
    @Autowired
    private TripLogRepository repository;

    @Autowired
    private DriverAssignmentRepository driverAssignmentRepository;

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    public TripLog saveTrip(TripLog trip) {

        Long driverId = trip.getDriver().getId();
        Long vehicleId = trip.getVehicle().getId();

        Driver driver = driverRepository.findById(driverId).get();
        Vehicle vehicle = vehicleRepository.findById(vehicleId).get();

        if (!driver.getStatus().equals("BUSY")) {
            throw new RuntimeException("Driver not assigned");
        }

        if (!vehicle.getStatus().equals("BUSY")) {
            throw new RuntimeException("Vehicle not assigned");
        }

        return repository.save(trip);
    }


    public TripLog endTrip(Long tripId) {

        TripLog trip = repository.findById(tripId).get();

        trip.setStatus("COMPLETED");
        trip.setEndAt(java.time.LocalDateTime.now());

        Long driverId = trip.getDriver().getId();
        Long vehicleId = trip.getVehicle().getId();

        Driver driver = driverRepository.findById(driverId).get();
        driver.setStatus("AVAILABLE");
        driverRepository.save(driver);

        Vehicle vehicle = vehicleRepository.findById(vehicleId).get();
        vehicle.setStatus("ACTIVE");
        vehicleRepository.save(vehicle);

        List<DriverAssignment> assignments =
                driverAssignmentRepository.findByDriver_Id(driverId);

        for (DriverAssignment a : assignments) {
            if (a.getStatus().equals("ASSIGNED")) {
                a.setStatus("COMPLETED");
                driverAssignmentRepository.save(a);
            }
        }

        return repository.save(trip);
    }

    public List<TripLog> getAllTrips() {
        return repository.findAll();
    }
    public List<TripLog> getByDriver(Long driverId) {
        return repository.findByDriver_Id(driverId);
    }
    public List<TripLog> getByVehicle(Long vehicleId) {
        return repository.findByVehicle_Id(vehicleId);
    }
    public List<TripLog> getByStatus(String status) {
        return repository.findByStatus(status);
    }
}