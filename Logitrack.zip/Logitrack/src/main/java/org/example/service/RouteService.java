package org.example.service;
import org.example.entity.Route;
import org.example.repository.RouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class RouteService {
    @Autowired
    private RouteRepository routeRepository;
    public Route saveRoutes(Route route) {
        return routeRepository.save(route);
    }

    public List<Route> getAllRoutes() {
        return routeRepository.findAll();
    }

    public List<Route> getRoutesByStatus(String status) {
        return routeRepository.findByStatus(status);
    }

    public Route getRouteById(Long id) {
        return routeRepository.findById(id).orElse(null);
    }
}