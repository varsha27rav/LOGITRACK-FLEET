package org.example.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "trip_log")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TripLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;

    @ManyToOne
    @JoinColumn(name = "driver_id", nullable = false)
    private Driver driver;
    @ManyToOne
    @JoinColumn(name = "route_id", nullable = false)
    private Route route;
    @Column(nullable = false)
    private LocalDateTime startAt;

    private LocalDateTime endAt;

    private Double distanceKm;

    @Column(columnDefinition = "TEXT")
    private String notes;
    @Column(nullable = false, length = 20)
    private String status = "IN_PROGRESS";
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (startAt == null) startAt = LocalDateTime.now();
    }
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}