package org.example.controller;
import org.example.entity.TripLog;
import org.example.service.TripLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/trips")
public class TripLogController {

    @Autowired
    private TripLogService tripLogService;

    @PostMapping
    public TripLog startTrip(@RequestBody TripLog trip) {
        return tripLogService.saveTrip(trip);
    }

    @GetMapping
    public List<TripLog> getAllTrips() {
        return tripLogService.getAllTrips();
    }

    @GetMapping("/driver/{driverId}")
    public List<TripLog> getByDriver(@PathVariable Long driverId) {
        return tripLogService.getByDriver(driverId);
    }

    @PutMapping("/end/{tripId}")
    public TripLog endTrip(@PathVariable Long tripId) {
        return tripLogService.endTrip(tripId);
    }

    @GetMapping("/vehicle/{vehicleId}")
    public List<TripLog> getByVehicle(@PathVariable Long vehicleId) {
        return tripLogService.getByVehicle(vehicleId);
    }

    @GetMapping("/status/{status}")
    public List<TripLog> getByStatus(@PathVariable String status) {
        return tripLogService.getByStatus(status);
    }
}