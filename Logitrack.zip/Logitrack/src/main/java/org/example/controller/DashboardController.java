package org.example.controller;

import org.example.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private TripLogRepository tripLogRepository;

    @GetMapping
    public Map<String, Object> getDashboard() {

        Map<String, Object> data = new HashMap<>();

        data.put("totalDrivers", driverRepository.count());
        data.put("availableDrivers", driverRepository.findByStatus("AVAILABLE").size());
        data.put("busyDrivers", driverRepository.findByStatus("BUSY").size());

        data.put("totalVehicles", vehicleRepository.count());
        data.put("activeVehicles", vehicleRepository.findByStatus("ACTIVE").size());
        data.put("busyVehicles", vehicleRepository.findByStatus("BUSY").size());

        data.put("totalTrips", tripLogRepository.count());
        data.put("activeTrips", tripLogRepository.findByStatus("IN_PROGRESS").size());
        data.put("completedTrips", tripLogRepository.findByStatus("COMPLETED").size());

        return data;
    }
}