package org.example.controller;
import org.example.entity.RouteSchedule;
import org.example.service.RouteScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/schedules")
public class RouteScheduleController {
    @Autowired
    private RouteScheduleService routeScheduleService;
    @PostMapping
    public RouteSchedule createSchedule(@RequestBody RouteSchedule schedule) {
        return routeScheduleService.saveSchedule(schedule);
    }
    @GetMapping
    public List<RouteSchedule> getAllSchedules() {
        return routeScheduleService.getAllSchedules();
    }
    @GetMapping("/vehicle/{vehicleId}")
    public List<RouteSchedule> getByVehicle(@PathVariable Long vehicleId) {
        return routeScheduleService.getByVehicle(vehicleId);
    }
    @GetMapping("/status/{status}")
    public List<RouteSchedule> getByStatus(@PathVariable String status) {
        return routeScheduleService.getByStatus(status);
    }
}