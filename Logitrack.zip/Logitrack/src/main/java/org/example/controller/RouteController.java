package org.example.controller;
import org.example.entity.Route;
import org.example.service.RouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/routes")
public class RouteController {
    @Autowired
    private RouteService routeService;

    @PostMapping
    public Route saveRoute(@RequestBody Route route){
        return routeService.saveRoutes(route);
    }

    @GetMapping
    public List<Route> getAllRoutes() {
        return routeService.getAllRoutes();
    }
    @GetMapping("/status/{status}")
    public List<Route> getRoutesByStatus(@PathVariable String status) {
        return routeService.getRoutesByStatus(status);
    }
}

