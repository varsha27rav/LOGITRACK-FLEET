package org.example.controller;

import org.example.entity.DriverAssignment;
import org.example.service.DriverAssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/assignments")
public class DriverAssignmentController {

    @Autowired
    private DriverAssignmentService driverAssignmentService;

    @PostMapping
    public DriverAssignment assignDriver(@RequestBody DriverAssignment assignment) {
        return driverAssignmentService.saveAssignment(assignment);
    }

    @GetMapping
    public List<DriverAssignment> getAllAssignments() {
        return driverAssignmentService.getAllAssignments();
    }

    @GetMapping("/driver/{driverId}")
    public List<DriverAssignment> getByDriver(@PathVariable Long driverId) {
        return driverAssignmentService.getByDriver(driverId);
    }

    @GetMapping("/vehicle/{vehicleId}")
    public List<DriverAssignment> getByVehicle(@PathVariable Long vehicleId) {
        return driverAssignmentService.getByVehicle(vehicleId);
    }

    @GetMapping("/status/{status}")
    public List<DriverAssignment> getByStatus(@PathVariable String status) {
        return driverAssignmentService.getByStatus(status);
    }
}