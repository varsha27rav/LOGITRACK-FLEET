package org.example.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TripLogDTO {
    private Long Id;
    private Long vehicleId;
    private Long driverId;
    private Long routeId;
    private LocalDateTime startAt;
    private LocalDateTime endAt;
    private Double distanceKm;
    private String notes;
    private String status;

}
