package org.example.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RouteScheduleDTO {
    private Long id;
    private Long vehicleId;
    private Long routeId;
    private LocalDateTime departureAt;
    private LocalDateTime arrivalAt;
    private Long dispatcherId;
    private String status;

}
