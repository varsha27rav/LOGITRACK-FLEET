package org.example.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DriverAssignmentDTO {
    private Long id;
    private Long driverId;
    private Long vehicleId;
    private Long scheduleId;
    private String status;
}
